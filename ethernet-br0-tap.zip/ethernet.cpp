#include <pcap.h>
#include <libtcpip.h>
#ifdef _WIN32
#include <iphlpapi.h>
#else
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>

#include <netpacket/packet.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <net/if_packet.h>
#include <net/ethernet.h> /* the L2 protocols */
#include <net/route.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <linux/if_ether.h>

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ifaddrs.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#endif

#include "gw.h"
#include "ipv4.h"
#include "etharp.h"
#include "ethernet.h"

#pragma comment(lib, "Packet.lib")
#pragma comment(lib, "wpcap.lib")
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "Iphlpapi.lib")

namespace vgw {
    uint32_t                                                ETHERNET_IP = INADDR_ANY;
    uint32_t                                                ETHERNET_NGW = INADDR_ANY;
    uint32_t                                                ETHERNET_MASK = INADDR_ANY;
    struct eth_addr                                         ETHERNET_MAC;
    boost::asio::io_context                                 ETHERNET_CONTEXT_;
    Byte                                                    ETHERNET_BUFFER_[65535];
    boost::asio::ip::udp::endpoint                          ETHERNET_ENDPOINT_;
    uint32_t                                                ETHERNET_IFINDEX_;

    #ifndef _WIN32
    static char                                             ETHERNET_TAP[] = "vgw"; 
    static int                                              ETHERNET_BR0 = -1;
    static std::string                                      ETHERNET_BR;
    static std::string                                      ETHERNET_DEV;
    static uint32_t                                         ETHERNET_DEV_IP = INADDR_ANY;
    static uint32_t                                         ETHERNET_DEV_MASK = INADDR_ANY;
    #endif
    static pcap_t*                                          ETHERNET_NIC = NULL;
    static bool                                             ETHERNET_FIN = false;

    #ifdef _WIN32
    inline static std::string pcap_live_get_packet_device(const std::string& device) {
        if (device.empty()) {
            return NULL;
        }

        std::string device_ = device;
        std::transform(device_.begin(), device_.end(), device_.begin(), tolower);

        struct pcap_if* alldevs;
        char errbuf[PCAP_ERRBUF_SIZE];

        int err = pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf);
        if (err < 0) {
            return NULL;
        }

        for (struct pcap_if* d = alldevs; d != NULL; d = d->next) {
            std::string description;
            if (d->description) {
                description = d->description;
            }

            if (description.empty()) {
                continue;
            }

            std::transform(description.begin(), description.end(), description.begin(), tolower);
            if (description.find(device_) != std::string::npos) {
                std::string name = d->name;
                pcap_freealldevs(alldevs);
                return name;
            }
        }
        pcap_freealldevs(alldevs);
        return NULL;
    }

    inline static void ethernet_gc_collect() {
        static std::shared_ptr<boost::asio::deadline_timer> t = make_shared_object<boost::asio::deadline_timer>(ETHERNET_CONTEXT_);
        auto callbackf = [](const boost::system::error_code& ec) {
            SetProcessWorkingSetSize(GetCurrentProcess(), UINT_MAX, UINT_MAX);
            ethernet_gc_collect();
        };
        t->expires_from_now(boost::posix_time::seconds(10));
        t->async_wait(callbackf);
    }
    #endif

    inline static pcap_t* pcap_live_open_packet_device(std::string device_) {
        char errbuf[PCAP_ERRBUF_SIZE];
        #ifdef _WIN32
        device_ = pcap_live_get_packet_device(device_);
        if (device_.empty()) {
            return NULL;
        }

        pcap_t* device = pcap_open_live(
            device_.data(), // name of the device
            65536, // portion of the packet to capture
                   // 65536 guarantees that the whole packet
                   // will be captured on all the link layers
            PCAP_OPENFLAG_PROMISCUOUS | // promiscuous mode
            PCAP_OPENFLAG_MAX_RESPONSIVENESS,
            0, // read timeout
            errbuf); // error buffer
        #else
        if (device_.empty()) {
            return NULL;
        }

        pcap_t* device = pcap_open_live(
            device_.data(), // name of the device
            65536, // portion of the packet to capture
                   // 65536 guarantees that the whole packet
                   // will be captured on all the link layers
            1, // promiscuous mode
            0, // read timeout
            errbuf); // error buffer
        #endif
        if (!device) {
            return NULL;
        }

        /* Must is ethernet */
        int datalink = pcap_datalink(device);
        if (datalink != DLT_EN10MB && datalink != DLT_EN3MB) {
            pcap_close(device);
            return NULL;
        }

        /* Set promiscuous mode */ 
        pcap_set_promisc(device, 1);

        #ifdef _WIN32
        typedef PCAP_AVAILABLE_1_5 int(__cdecl *proc_pcap_set_immediate_mode)(pcap_t*, int);

        proc_pcap_set_immediate_mode pcap_set_immediate_mode_ = (proc_pcap_set_immediate_mode)
            GetProcAddress(GetModuleHandle(TEXT("wpcap.dll")), "pcap_set_immediate_mode");
        if (pcap_set_immediate_mode_) {
            pcap_set_immediate_mode_(device, 1);
        }
        #else
        /* Set immediate mode */
        pcap_set_immediate_mode(device, 1);
        #endif

        /* Only capture IN */
        pcap_setdirection(device, PCAP_D_IN);

        static const int MAX_BUFFER_SIZE = 1 * 1024 * 1024;
        #ifdef _WIN32
        /* We want any responses back ASAP */
        if (pcap_setmintocopy(device, 0)) {
            pcap_close(device);
            return NULL;
        }

        /* Set the buffer size for a not-yet-activated capture handle */
        pcap_setbuff(device, MAX_BUFFER_SIZE);
        #else
        /* Set the buffer size for a not-yet-activated capture handle */
        pcap_set_buffer_size(device, MAX_BUFFER_SIZE);
        #endif

        bpf_u_int32 netmask = ETHERNET_MASK;
        if (netmask == INADDR_ANY) {
            netmask = INADDR_NONE;
        }

        char rules[8096];
        sprintf(rules, "ether dst %02x:%02x:%02x:%02x:%02x:%02x or ether dst ff:ff:ff:ff:ff:ff",
            ETHERNET_MAC.s_data[0],
            ETHERNET_MAC.s_data[1],
            ETHERNET_MAC.s_data[2],
            ETHERNET_MAC.s_data[3],
            ETHERNET_MAC.s_data[4],
            ETHERNET_MAC.s_data[5]);

        /* Compile the filter */
        struct bpf_program fcode;
        if (pcap_compile(device, &fcode, rules, 1, netmask)) {
            pcap_close(device);
            return NULL;
        }

        /* Set the filter */
        if (pcap_setfilter(device, &fcode)) {
            pcap_close(device);
            return NULL;
        }
        return device;
    }

    inline static void ethernet_loopback() {
        auto loopbackf = [] {
            SetThreadPriorityToMaxLevel();

            boost::system::error_code ec_;
            boost::asio::io_context::work work_(ETHERNET_CONTEXT_);
            ETHERNET_CONTEXT_.run(ec_);
        };
        std::thread(loopbackf).detach();
    }

    inline static void ethernet_init() {
        ETHERNET_FIN = false;
        ETHERNET_CONTEXT_.restart();

        libtcpip_loopback(ETHERNET_IP, ETHERNET_IP, ETHERNET_MASK, (LIBTCPIP_IPV4_OUTPUT)ipv4_output);
        ipv4_init();
        etharp_init();
        ethernet_loopback();
    }

    inline static int64_t MAC2I64(struct eth_addr& addr) {
        return (int64_t)addr.s_zero.w << 32 | addr.s_zero.dw;
    }

    inline static void ethernet_input(struct eth_hdr* packet, int proto, std::shared_ptr<char>& buf, int len) {
        switch (proto)
        {
            case ETHTYPE_IP: // Internet Protocol, Version 4 (IPv4)
            {
                int iplen = len - sizeof(*packet);
                if (iplen < ip_hdr::IP_HLEN) {
                    break;
                }
    
                struct ip_hdr* iphdr = (struct ip_hdr*)(packet + 1);
                etharp_add(packet->src, iphdr->src);
    
                if (ip_hdr::IPH_PROTO(iphdr) == ip_hdr::IP_PROTO_TCP) {
                    libtcpip_input(iphdr, iplen);
                    return;
                }
    
                iphdr = ip_hdr::Parse(iphdr, iplen);
                if (iphdr) {
                    ipv4_input(iphdr, iplen);
                }
                break;
            }
            case ETHTYPE_ARP: // Address Resolution Protocol (ARP)
            {
                etharp_input(packet, (struct etharp_hdr*)(packet + 1), len - sizeof(*packet));
                break;
            }
        }
    }

    inline static void pcap_live_loop_packet_device(u_char *, const struct pcap_pkthdr* pkg_hdr, const u_char* pkg_data) {
        struct eth_hdr* packet = (struct eth_hdr*)pkg_data;
        int len = pkg_hdr->len;

        int proto = ntohs(packet->proto);
        switch (proto) {
        case ETHTYPE_IP:
            {
                if (MAC2I64(packet->dst) != MAC2I64(ETHERNET_MAC)) {
                    return;
                }
                break;
            }
        case ETHTYPE_ARP:
            {
                int64_t MAC = MAC2I64(packet->dst);
                if (MAC != 0xFFFFFFFFFFFF && MAC != MAC2I64(ETHERNET_MAC)) {
                    return;
                }
                break;
            }
        default:
            {
                return;
            }
        };

        std::shared_ptr<char> buf = std::shared_ptr<char>((char*)malloc(len), free);
        memcpy(buf.get(), pkg_data, len);
        ETHERNET_CONTEXT_.post(std::bind(ethernet_input, packet, proto, buf, len));
    }

    #ifndef _WIN32
    inline static bool ethernet_set_promisc(const std::string& device, int promisc);

    inline static int ethernet_open_tap_device() {
        int handle = open("/dev/tun", O_RDWR);
        if (handle == -1) {
            handle = open("/dev/net/tun", O_RDWR); 
            if (handle == -1) {
                return -1;
            }
        }

        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));

        ifr.ifr_flags = IFF_TAP | IFF_NO_PI;
        strncpy(ifr.ifr_name, ETHERNET_TAP, IFNAMSIZ);

        if (ioctl(handle, TUNSETIFF, &ifr)) {
            close(handle);
            return -1;
        }

        memset(&ifr, 0, sizeof(ifr));
        if (ioctl(handle, TUNGETIFF, &ifr)) {
            close(handle);
            return -1;
        }

        int sockctl_ = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (sockctl_ == -1) {
            close(handle);
            return -1;
        }

        ifr.ifr_flags |= IFF_UP;
        if (ioctl(sockctl_, SIOCSIFFLAGS, &ifr)) {
            close(handle);
            close(sockctl_);
            return -1;
        }

        ifr.ifr_mtu = 1500;
        if (ioctl(sockctl_, SIOCSIFMTU, &ifr)) {
            close(handle);
            close(sockctl_);
            return -1;
        }
        else {
            memset(&ifr, 0, sizeof(ifr));
            strcpy(ifr.ifr_name, ETHERNET_TAP);
    
            // 设置IP地址
            struct sockaddr_in* addr = (struct sockaddr_in*)&(ifr.ifr_addr);
            addr->sin_family = AF_INET;
            addr->sin_addr.s_addr = ETHERNET_IP;
            if (ioctl(sockctl_, SIOCSIFADDR, &ifr)) {
                close(handle);
                close(sockctl_);
                return -1;
            }
            else {
                // 设置网络掩码
                memset(&ifr.ifr_addr, 0, sizeof(ifr.ifr_addr));

                struct sockaddr_in maskAddr;
                memset(&maskAddr, 0, sizeof(maskAddr));

                maskAddr.sin_family = AF_INET;
                maskAddr.sin_addr.s_addr = ETHERNET_MASK;

                memcpy(&ifr.ifr_netmask, &maskAddr, sizeof(ifr.ifr_netmask));
                ioctl(sockctl_, SIOCSIFNETMASK, &ifr);
            }

            // 设置MAC地址
            ifr.ifr_addr.sa_family = ARPHRD_ETHER;
            strcpy(ifr.ifr_name, ETHERNET_TAP);
            memcpy((unsigned char*)ifr.ifr_hwaddr.sa_data, ETHERNET_MAC.s_data, 6);
            if (ioctl(sockctl_, SIOCSIFHWADDR, &ifr)) {
                close(handle);
                close(sockctl_);
                return -1;
            }

            // 设置混杂模式
            if (!ethernet_set_promisc(ETHERNET_TAP, 1)) {
                close(handle);
                close(sockctl_);
                return -1;
            }
        }
        close(sockctl_);
        return handle;
    }

    inline static void ethernet_loop_tap_device() {
        struct pcap_pkthdr pkg_hdr;
        memset(&pkg_hdr, 0, sizeof(pkg_hdr));

        while (!ETHERNET_FIN) {
            char buff[65536];
            int by = read(ETHERNET_BR0, buff, sizeof(buff));
            if (by < 0) {
                break;
            }

            pkg_hdr.len = by;
            pkg_hdr.caplen = by;
            pcap_live_loop_packet_device(NULL, &pkg_hdr, (u_char*)buff);
        }
    }

    inline static void ethernet_del_linux_bridge() {
        char cmd[8096];
        sprintf(cmd, "/sys/class/net/%s", ETHERNET_BR.data());
        if (access(cmd, F_OK) == 0) {
            sprintf(cmd, "ifconfig %s down", ETHERNET_BR.data());
            system(cmd);

            sprintf(cmd, "brctl delbr %s", ETHERNET_BR.data());
            system(cmd);
        }

        if (ETHERNET_DEV_IP && ETHERNET_DEV_MASK) {
            sprintf(cmd, "ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d up", 
                ETHERNET_DEV.data(),
                ((uint8_t*)&ETHERNET_DEV_IP)[0],
                ((uint8_t*)&ETHERNET_DEV_IP)[1],
                ((uint8_t*)&ETHERNET_DEV_IP)[2],
                ((uint8_t*)&ETHERNET_DEV_IP)[3],
                
                ((uint8_t*)&ETHERNET_DEV_MASK)[0],
                ((uint8_t*)&ETHERNET_DEV_MASK)[1],
                ((uint8_t*)&ETHERNET_DEV_MASK)[2],
                ((uint8_t*)&ETHERNET_DEV_MASK)[3]);
            system(cmd);
        }

        if (ETHERNET_NGW) {
            sprintf(cmd, "route add default gw %d.%d.%d.%d", 
                ((uint8_t*)&ETHERNET_NGW)[0],
                ((uint8_t*)&ETHERNET_NGW)[1],
                ((uint8_t*)&ETHERNET_NGW)[2],
                ((uint8_t*)&ETHERNET_NGW)[3]);
            system(cmd);
        }
        ethernet_set_promisc(ETHERNET_DEV, 0);
    }

    inline static void ethernet_open_linux_bridge() {
        char cmd[8096];
        sprintf(cmd, "brctl addbr %s", ETHERNET_BR.data());
        system(cmd);

        sprintf(cmd, "brctl addif %s %s", ETHERNET_BR.data(), ETHERNET_DEV.data());
        system(cmd);

        sprintf(cmd, "brctl addif %s %s", ETHERNET_BR.data(), ETHERNET_TAP);
        system(cmd);

        sprintf(cmd, "brctl stp %s off", ETHERNET_BR.data());
        system(cmd);

        if (ETHERNET_DEV_IP && ETHERNET_DEV_MASK) {
            sprintf(cmd, "ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d up", 
                ETHERNET_BR.data(),
                ((uint8_t*)&ETHERNET_DEV_IP)[0],
                ((uint8_t*)&ETHERNET_DEV_IP)[1],
                ((uint8_t*)&ETHERNET_DEV_IP)[2],
                ((uint8_t*)&ETHERNET_DEV_IP)[3],
                
                ((uint8_t*)&ETHERNET_DEV_MASK)[0],
                ((uint8_t*)&ETHERNET_DEV_MASK)[1],
                ((uint8_t*)&ETHERNET_DEV_MASK)[2],
                ((uint8_t*)&ETHERNET_DEV_MASK)[3]);
            system(cmd);
        }

        sprintf(cmd, "ifconfig %s hw ether %02x:%02x:%02x:%02x:%02x:%02x", 
            ETHERNET_BR.data(),
            ETHERNET_MAC.s_data[0],
            ETHERNET_MAC.s_data[1],
            ETHERNET_MAC.s_data[2],
            ETHERNET_MAC.s_data[3],
            ETHERNET_MAC.s_data[4],
            ETHERNET_MAC.s_data[5]);
        system(cmd);

        sprintf(cmd, "ip addr flush dev %s", ETHERNET_DEV.data());
        system(cmd);

        sprintf(cmd, "ip addr flush dev %s", ETHERNET_TAP);
        system(cmd);

        if (ETHERNET_NGW) {
            sprintf(cmd, "route add default gw %d.%d.%d.%d", 
                ((uint8_t*)&ETHERNET_NGW)[0],
                ((uint8_t*)&ETHERNET_NGW)[1],
                ((uint8_t*)&ETHERNET_NGW)[2],
                ((uint8_t*)&ETHERNET_NGW)[3]);
            system(cmd);
        }
        ethernet_set_promisc(ETHERNET_BR, 1);
        ethernet_set_promisc(ETHERNET_TAP, 1);
        ethernet_set_promisc(ETHERNET_DEV, 1);
    }

    inline static uint32_t ethernet_get_ip_address(int handle, const std::string& device) {
        if (handle == -1 || device.empty()) {
            return INADDR_ANY;
        }

        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        strcpy(ifr.ifr_name, device.data());   

        struct sockaddr_in* addr = (struct sockaddr_in*)&(ifr.ifr_addr);
        addr->sin_family = AF_INET;
        addr->sin_addr.s_addr = 0;

        if (ioctl(handle, SIOCGIFADDR, &ifr) == -1) {
            return INADDR_ANY;
        }
        return addr->sin_addr.s_addr;
    }

    inline static uint32_t ethernet_get_netmask(int handle, const std::string& device) {
        if (handle == -1 || device.empty()) {
            return INADDR_ANY;
        }

        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        strcpy(ifr.ifr_name, device.data());      

        struct sockaddr_in* addr = (struct sockaddr_in*)&(ifr.ifr_netmask);
        addr->sin_family = AF_INET;     

        if (ioctl(handle, SIOCGIFNETMASK, &ifr) == -1) {
            return INADDR_ANY;
        }
        return addr->sin_addr.s_addr;
    }

    inline static int ethernet_open_br0_device() {
        int handle = socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
        if (handle == -1) {
            return -1;
        }
        else {
            ETHERNET_DEV_IP = ethernet_get_ip_address(handle, ETHERNET_DEV);
            ETHERNET_DEV_MASK = ethernet_get_netmask(handle, ETHERNET_DEV);
            close(handle);

            if (!ETHERNET_DEV_IP || !ETHERNET_DEV_MASK) {
                return -1;
            }
        }

        handle = ethernet_open_tap_device();
        if (handle == -1) {
            return -1;
        }

        ethernet_open_linux_bridge();
        return handle;
    }

    inline static void ethernet_close_br0_device() {
        if (ETHERNET_BR.size()) {
            int handle = ETHERNET_BR0;
            if (handle != -1) {
                ETHERNET_BR0 = -1;
                close(handle);
            }
            ethernet_del_linux_bridge();
        }
    }
    #endif

    inline static bool ethernet_loopback(const std::string& device) {
        #ifdef _WIN32
        ETHERNET_NIC = pcap_live_open_packet_device(device);
        if (!ETHERNET_NIC) {
            return false;
        }
        #else
        ETHERNET_DEV = device;
        if (ETHERNET_BR.size()) {
            ETHERNET_BR0 = ethernet_open_br0_device();
            if (ETHERNET_BR0 == -1) {
                return false;
            }
        }
        else {
            ETHERNET_NIC = pcap_live_open_packet_device(device);
            if (!ETHERNET_NIC) {
                return false;
            }
        }
        #endif

        ethernet_init();
        fprintf(stdout, 
            #ifdef _WIN32
            "Loopback:\r\nIP:    %s\r\nNgw:   %s\r\nMask:  %s\r\nMac:   %02x:%02x:%02x:%02x:%02x:%02x\r\nEther: %s\r\n",
            #else
            "Loopback:\r\nIP:    %s\r\nNgw:   %s\r\nMask:  %s\r\nMac:   %02x:%02x:%02x:%02x:%02x:%02x\r\n%sEther: %s\r\n",
            #endif
            boost::asio::ip::address_v4(htonl(ETHERNET_IP)).to_string().data(),
            boost::asio::ip::address_v4(htonl(ETHERNET_NGW)).to_string().data(),
            boost::asio::ip::address_v4(htonl(ETHERNET_MASK)).to_string().data(),
            ETHERNET_MAC.s_data[0],
            ETHERNET_MAC.s_data[1],
            ETHERNET_MAC.s_data[2],
            ETHERNET_MAC.s_data[3],
            ETHERNET_MAC.s_data[4],
            ETHERNET_MAC.s_data[5],
            #ifndef _WIN32
            (ETHERNET_BR.empty() ? ETHERNET_BR : ("Br:    " + ETHERNET_BR + "\r\n")).data(),
            #endif
            device.data());
        #ifdef _WIN32
        ethernet_gc_collect();
        pcap_loop(ETHERNET_NIC, -1, pcap_live_loop_packet_device, NULL);
        #else
        if (ETHERNET_NIC) {
            pcap_loop(ETHERNET_NIC, -1, pcap_live_loop_packet_device, NULL);
        }
        else {
            ethernet_loop_tap_device();
        }
        #endif
        ethernet_release();
        #ifndef _WIN32
        ethernet_close_br0_device();
        #endif
        return true;
    }

    inline static struct sockaddr* ethernet_get_sockaddr_v4(struct pcap_addr* addresses) {
        if (!addresses) {
            return NULL;
        }
        for (;;) {
            struct sockaddr* address = addresses->addr;
            if (!address || address->sa_family != AF_INET) {
                if (!addresses->next) {
                    return NULL;
                }
                addresses = addresses->next;
            }
            else if (address->sa_family == AF_INET) {
                return address;
            }
        }
    }

    #ifdef _WIN32
    inline static PIP_ADAPTER_INFO ethernet_get_interface(uint32_t dwIndex, std::unique_ptr<char[]>& pAdapterPtr) {
        ULONG ulAdapterSize = 0;

        pAdapterPtr = std::make_unique<char[]>(sizeof(IP_ADAPTER_INFO));
        if (GetAdaptersInfo((PIP_ADAPTER_INFO)(pAdapterPtr.get()), &ulAdapterSize)) {
            pAdapterPtr.reset();
            pAdapterPtr = std::make_unique<char[]>(ulAdapterSize);
        }

        if (GetAdaptersInfo((PIP_ADAPTER_INFO)(pAdapterPtr.get()), &ulAdapterSize)) {
            return NULL;
        }

        auto pAdapter = (PIP_ADAPTER_INFO)pAdapterPtr.get();
        while (pAdapter) {
            if (*pAdapter->AdapterName == '\x0') {
                continue;
            }

            if (pAdapter->Index == dwIndex) {
                return pAdapter;
            }
            pAdapter = pAdapter->Next;
        }
        return NULL;
    }

    inline static std::string ethernet_get_interface_key(uint32_t dwIndex) {
        std::unique_ptr<char[]> pAdapterPtr;
        PIP_ADAPTER_INFO pi = ethernet_get_interface(dwIndex, pAdapterPtr);
        if (!pi) {
            return "";
        }
        return pi->Description;
    }

    uint32_t ethernet_get_interface(uint32_t dwIndex) {
        std::unique_ptr<char[]> pAdapterPtr;
        PIP_ADAPTER_INFO pi = ethernet_get_interface(dwIndex, pAdapterPtr);
        if (!pi) {
            return INADDR_ANY;
        }
        IP_ADDR_STRING* pa = &pi->IpAddressList;
        while (pa) {
            uint32_t dw = pa->Context;
            if (dw != INADDR_ANY && dw != INADDR_BROADCAST) {
                return dw;
            }
            pa = pa->Next;
        }
        return INADDR_ANY;
    }
    #else
    inline static uint32_t ethernet_interface_ip(uint32_t gw) {
        int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (fd == -1) {
            return INADDR_ANY;
        }
        int flags = fcntl(fd, F_GETFD, 0);
        if (flags == -1 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) == -1) {
            close(fd);
            return INADDR_ANY;
        }
        struct sockaddr_in connect_addr;
        memset(&connect_addr, 0, sizeof(connect_addr));     
        connect_addr.sin_addr.s_addr = gw;
        connect_addr.sin_port = 53;
        connect_addr.sin_family = AF_INET;          
        int hr = connect(fd, (struct sockaddr*)&connect_addr, sizeof(connect_addr));
        if (hr == -1) {
            hr = errno;
            if (hr != EINPROGRESS) {
                close(fd);
                return INADDR_ANY;
            }
        }   
        struct sockaddr_in sock_addr;
        int sock_len = sizeof(sock_addr);
        memset(&sock_addr, 0, sizeof(sock_addr));   
        if (getsockname(fd, (struct sockaddr*)&sock_addr, (socklen_t*)&sock_len)) {
            close(fd);
            return INADDR_ANY;
        }
        else {
            close(fd);
        }
        if (sock_addr.sin_family != AF_INET) {
            return INADDR_ANY;
        }
        return sock_addr.sin_addr.s_addr;
    }

    inline static std::string ethernet_interface_name(uint32_t address) {
        if (address == INADDR_ANY || address == INADDR_NONE) {
            return "";
        }
        #if (!defined(ANDROID) || __ANDROID_API__ >= 24)
        struct ifaddrs* ifa = NULL;
        if (getifaddrs(&ifa) == -1) {
            return "";
        }
        struct ifaddrs* oifa = ifa;
        while (NULL != ifa) {
            struct sockaddr* addr = ifa->ifa_addr;
            if (NULL != addr) {
                switch (addr->sa_family) {
                    case AF_INET:
                    {
                        struct sockaddr_in* in4_addr = (struct sockaddr_in*)addr;
                        if (in4_addr->sin_addr.s_addr != address) {
                            break;
                        }
                        return ifa->ifa_name;
                    }
                };
            }
            ifa = ifa->ifa_next;
        }

        if (NULL != oifa) {
            freeifaddrs(oifa);
        }
        #endif
        return "";
    }
    
    inline static uint32_t ethernet_interface_index(const std::string& device) {
        if (device.empty()) {
            return UINT_MAX;
        }

        int sock_v4 = socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
        if (sock_v4 == -1) {
            return UINT_MAX;
        }

        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        strncpy(ifr.ifr_name, device.data(), device.size());
        if (ioctl(sock_v4, SIOGIFINDEX, &ifr) == -1) {
            close(sock_v4);
            return UINT_MAX;
        }
        else {
            close(sock_v4);
            return ifr.ifr_ifindex;
        }
    }
    
    inline static bool ethernet_set_promisc(const std::string& device, int promisc) {
        if (device.empty()) {
            return false;
        }

        int sockfd_ = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (sockfd_ == -1) {
            return false;
        }

        struct ifreq ifr;
        strcpy(ifr.ifr_name, device.data());
        if (ioctl(sockfd_, SIOCGIFFLAGS, &ifr)){
            close(sockfd_);
            return false;
        }

        if (promisc) {
            ifr.ifr_flags |= IFF_PROMISC;
        }
        else {
            ifr.ifr_flags &= ~IFF_PROMISC;
        }

        if (ioctl(sockfd_, SIOCSIFFLAGS, &ifr)) {
            close(sockfd_);
            return false;
        }
        else {
            close(sockfd_);
            return true;
        }
    }
    
    inline static bool ethernet_set_promisc(const std::string& device, int sockfd, int promisc) {
        if (device.empty() || sockfd == -1) {
            return false;
        }

        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        strncpy(ifr.ifr_name, device.data(), device.size());
        if (ioctl(sockfd, SIOGIFINDEX, &ifr)) {
            return false;
        }

        struct packet_mreq mreq;
        mreq.mr_ifindex = ifr.ifr_ifindex; /* if_nametoindex(device.data()); */
        mreq.mr_type = PACKET_MR_PROMISC;
        if (mreq.mr_ifindex == 0) {
            return false;
        }

        int action;
        if (promisc) {
            action = PACKET_ADD_MEMBERSHIP;
        }
        else {
            action = PACKET_DROP_MEMBERSHIP;
        }

        if (setsockopt(sockfd, SOL_PACKET, action, &mreq, sizeof(mreq)) != 0) {
            return false;
        }
        return true;
    }
    #endif

    #ifdef _WIN32
    bool ethernet_loopback(struct eth_addr& mac, uint32_t ip, uint32_t ngw, uint32_t mask) {
    #else
    bool ethernet_loopback(const std::string& br, struct eth_addr& mac, uint32_t ip, uint32_t ngw, uint32_t mask) {
    #endif
        if (ip == INADDR_ANY || ip == INADDR_NONE || ngw == INADDR_ANY || ngw == INADDR_NONE || mask == INADDR_ANY) {
            return false;
        }

        #ifndef _WIN32
        ETHERNET_BR = br;
        #endif
        ETHERNET_MAC = mac;
        ETHERNET_IP = ip;
        ETHERNET_NGW = ngw;
        ETHERNET_MASK = mask;

        struct pcap_if* alldevs;
        char errbuf[PCAP_ERRBUF_SIZE];

        #ifdef _WIN32
        if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) < 0) {
            return false;
        }

        DWORD dwIndex;
        if (GetBestInterface(ngw, &dwIndex) != ERROR_SUCCESS) {
            return false;
        }
        else {
            ETHERNET_IFINDEX_ = dwIndex;
        }

        std::string device = ethernet_get_interface_key(dwIndex);
        if (device.empty()) {
            return false;
        }
        return ethernet_loopback(device);
        #else
        int err = pcap_findalldevs(&alldevs, errbuf);
        if (err < 0) {
            return false;
        }

        std::string device = ethernet_interface_name(ethernet_interface_ip(ngw));
        if (device.empty()) {
            return false;
        }
        else {
            ETHERNET_IFINDEX_ = ethernet_interface_index(device);
        }
        return ethernet_loopback(device);
        #endif
    }

    bool ethernet_release() {
        if (ETHERNET_FIN) {
            return false;
        }
        auto callbackf = [] {
            ETHERNET_FIN = true;

            static pcap_t* pcap = ETHERNET_NIC;
            if (pcap) {
                ETHERNET_NIC = NULL;
                pcap_breakloop(pcap);
            }

            #ifndef _WIN32
            ethernet_close_br0_device();
            #endif

            etharp_release();
            ETHERNET_CONTEXT_.stop();
        };
        ETHERNET_CONTEXT_.post(callbackf);
        return true;
    }

    int ethernet_output(struct eth_hdr* eth, int len) {
        if (!eth || len < sizeof(*eth)) {
            return -1;
        }

        #ifndef _WIN32
        int handle = ETHERNET_BR0;
        if (handle != -1) {
            int err = write(handle, eth, len);
            return err != -1 ? 0 : -1;
        }
        #endif

        static pcap_t* pcap = ETHERNET_NIC;
        if (!pcap) {
            return -1;
        }
        return pcap_sendpacket(pcap, (u_char*)eth, len);
    }
}